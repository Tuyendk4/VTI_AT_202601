/*
 *  Copyright 2016-2026 Qameta Software Inc
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package io.qameta.allure.model;

/**
 * The marker interface for model objects with status details.
 *
 * @author baev (Dmitry Baev).
 * @see TestResult
 * @see FixtureResult
 * @see StepResult
 * @see ExecutableItem
 * @see WithStatus
 * @since 2.0
 */
public interface WithStatusDetails extends WithStatus {

    /**
     * Gets status details.
     *
     * @return the status details
     */
    StatusDetails getStatusDetails();

}
